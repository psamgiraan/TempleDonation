$(document).ready(function () {
$('#HorizontalVerticalExample').DataTable({
"scrollX": true,
"scrollY": 200,
});


